/**
 * 
 */
/**
 * 
 */
module Serializacao {
	requires json.simple;
}