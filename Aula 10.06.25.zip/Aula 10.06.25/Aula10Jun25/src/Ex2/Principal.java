package Ex2;

import java.util.ArrayList;
import java.util.List;

import Ex1.Aluno;

public class Principal {

	public static void main(String[] args) {
		// Criando objetos Aluno
		Aluno aluno1 = new Aluno("Éric", 24);
		Aluno aluno2 = new Aluno("Vanessa", 22);
		Aluno aluno3 = new Aluno("Bernardo", 22);
		List<Aluno> lista = new ArrayList<>();
		Arquivo arquivo = new Arquivo("alunos");
		arquivo.gravaArquivo(aluno1);
		arquivo.gravaArquivo(aluno2);
		arquivo.gravaArquivo(aluno3);

		lista = arquivo.leArquivo();

		for (Aluno a : lista) {
			System.out.println("Nome: " + a.getNome() + ", Idade: " + a.getIdade());
		}
	}
}
