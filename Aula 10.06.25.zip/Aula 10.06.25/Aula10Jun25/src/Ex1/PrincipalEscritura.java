package Ex1;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class PrincipalEscritura {

	public static void main(String[] args) {

		Aluno a1 = new Aluno("Vanessa", 22);
		Aluno a2 = new Aluno("João", 20);
		Aluno a3 = new Aluno("Maria", 19);

		try {
			// Quando tem true depois do arquivo, ele ativa o append e não sobreescreve o arquivo
			FileWriter arquivo = new FileWriter("alunos.txt", true);
			// FileWriter arquivo = new FileWriter("alunos.txt"); Assim sobreescreve
			BufferedWriter escritor = new BufferedWriter(arquivo);

			escritor.write(a1.getNome() + "," + a1.getIdade());
			escritor.newLine();

			escritor.write(a2.getNome() + "," + a2.getIdade());
			escritor.newLine();

			escritor.write(a3.getNome() + "," + a3.getIdade());
			escritor.newLine();

			escritor.close();
			arquivo.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
